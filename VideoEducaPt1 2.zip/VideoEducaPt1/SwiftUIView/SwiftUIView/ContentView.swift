//
//  ContentView.swift
//  SwiftUIView
//
//  Created by User on 17/10/23.
//

import SwiftUI

struct ContentView: View {
    
    @AppStorage("username") var username: String = ""
    @AppStorage("E-mail") var email: String = ""
    
    var body: some View {
        NavigationStack {
            ZStack{
                
                Color.blue
                    .ignoresSafeArea()
                Image("vector")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 390, height: 100)
                    .offset(x: 0, y:280)
                VStack {
                    Spacer()
                    Spacer()
                    Spacer()
                    Text("Quem é você?") // Título no topo da tela
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(Color.white)
                    Spacer()
                    
                    
                    TextField("Nome", text: $username)
                        .font(.system(size: 20)) // Ajuste o tamanho da fonte
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.white)) // Fundo arredondado
                        .multilineTextAlignment(.center) // Centralize o texto
                        .frame(width: 300, height: 50)
                    TextField("E-mail", text: $email)
                        .font(.system(size: 20)) // Ajuste o tamanho da fonte
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.white)) // Fundo arredondado
                        .multilineTextAlignment(.center) // Centralize o texto
                        .frame(width: 300, height: 80)
                    NavigationLink(destination: HelloView()) {
                        Text("Entrar")
                            .font(.system(size: 23, weight: .bold))
                            .foregroundColor(.blue)
                            .padding()
                            .frame(width: 150, height: 50)
                    }
                    .background(Color.white)
                    .cornerRadius(25)
                    
                    Spacer()
                    Spacer()
                }
            }
        }
    }
}




#Preview {
    ContentView()
}
