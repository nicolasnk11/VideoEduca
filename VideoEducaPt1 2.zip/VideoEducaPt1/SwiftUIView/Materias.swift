import SwiftUI

struct Materias: View {
    @AppStorage("username") var name: String = ""
    
    var body: some View{
        
        
        NavigationStack {
            ZStack{
                Image("Tela de Escolhas Disciplinas")
                    .ignoresSafeArea(.all)
                
                VStack {
                    Text("\(name), o que vamos estudar hoje?")
                        .font(.system(size: 35, weight: .bold))
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding()
                        .offset(x: 20, y: 80)
                        .foregroundColor(.white)
                    Spacer()
                    Spacer()
                    
                    Spacer()
                    Spacer()
                    NavigationLink(destination: Matematica()) {
                        Text("Matemática")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(.black)
                            .padding(.vertical, 45)
                            .frame(width: 270, height: 50)
                            .padding()
                    }
                    .background(Color.white)
                    .cornerRadius(15)
                    Spacer()
                    NavigationLink(destination: Fisica()) {
                        Text("Física")
                            .foregroundColor(.black)
                            .font(.system(size: 25, weight: .bold))
                            .padding(.vertical, 45)
                            .frame(width: 270, height: 50)
                            .padding()
                    }
                    .background(Color.white)
                    .cornerRadius(15)
                    Spacer()
                    NavigationLink(destination: Quimica()) {
                        Text("Química")
                            .foregroundColor(.black)
                            .font(.system(size: 25, weight: .bold))
                            .padding(.vertical, 45)
                            .frame(width: 270, height: 50)
                            .padding()
                    }
                    .background(Color.white)
                    .cornerRadius(15)
                    Spacer()
                    Spacer()
                    Spacer()
                    
                    
                }
                .background(
                    Image("vector")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 390, height: 100)
                        .offset(x: 0, y: 140)
                    
                )
                .background(
                    Color.blue)
                .edgesIgnoringSafeArea(.all)
                
            }
            
        }
    }
}


#Preview {
    Materias()
}
